import DashboardFundings from '../components/DashboardFundingsPage/DashboardFundings';

export default function DashboardFundingsPage() {
  return <DashboardFundings />;
}
