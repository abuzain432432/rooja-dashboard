import DashboardProducts from '../components/DashboardProductsPage/DashboardProducts';

export default function DashboardProductsPage() {
  return <DashboardProducts />;
}
