import DashboardOverview from '../components/DashboardOverviewPage/DashboardOverview';

export default function DashboardOverviewPage() {
  return <DashboardOverview />;
}
