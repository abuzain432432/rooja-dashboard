import DashboardPurchases from '../components/DashboardPurchasesPage/DashboardPurchases';

export default function DashboardPurchasesPage() {
  return <DashboardPurchases />;
}
