import DashboardAccounts from '../components/DashboardAccountsPage/DashboardAccounts.jsx';
export default function DashboardAccountsPage() {
  return <DashboardAccounts />;
}
