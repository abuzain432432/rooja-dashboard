import DashboardSettings from '../components/DashboardSettingsPage/DashboardSettings';

export default function DashboardSettingsPage() {
  return <DashboardSettings />;
}
