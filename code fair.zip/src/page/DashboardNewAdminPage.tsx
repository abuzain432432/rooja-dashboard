import DashboardNewAdmin from '../components/DashboardNewAdminPage/DashboardNewAdmin';

export default function DashboardNewAdminPage() {
  return <DashboardNewAdmin />;
}
