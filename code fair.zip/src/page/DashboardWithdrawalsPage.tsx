import DashboardWithdrawals from '../components/DashboardWithdrawalsPage/DashboardWithdrawals';

export default function DashboardWithdrawalsPage() {
  return <DashboardWithdrawals />;
}
